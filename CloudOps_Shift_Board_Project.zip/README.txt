╔═══════════════════════════════════════════════════════════════╗
║           CloudOps Shift Board — Project Package              ║
╚═══════════════════════════════════════════════════════════════╝

FILES IN THIS PACKAGE
─────────────────────
1. CloudOps_Shift_Board.html          ← Main dashboard (open in browser)
2. CloudOps_Shift_Board.xlsx          ← Shared Excel file (upload to SharePoint)
3. SETUP_GUIDE.html                   ← Full step-by-step setup guide
4. PowerAutomate_READ_Template.json   ← Reference for building the PA flow
5. README.txt                         ← This file

QUICK START (5 steps)
─────────────────────
Step 1: Upload CloudOps_Shift_Board.xlsx to your SharePoint document library

Step 2: Go to make.powerautomate.com
        Create flow: "CloudOps READ"
        Trigger: When HTTP request received | Method: GET | Anyone can trigger
        Add 8x Excel "List rows in table" actions (one per table)
        Add Response action with CORS header
        Save → copy the HTTP POST URL

Step 3: Open SETUP_GUIDE.html for the full step-by-step with exact expressions

Step 4: Open CloudOps_Shift_Board.html in browser
        Click ⚙ Setup → Enter URLs tab → paste READ flow URL → Save and connect

Step 5: Share CloudOps_Shift_Board.html with your team
        Each person does Step 4 once — after that it auto-loads every time

WHAT WORKS AUTOMATICALLY AFTER SETUP
──────────────────────────────────────
✓ Dashboard auto-loads all data when opened (no clicks)
✓ All sections: Zendesk, Jira, Limited Access, Provisioning,
  Information, Project Devices, Remote Hands, Handover
✓ Animated charts on Dashboard
✓ Editable cells — click any cell to edit
✓ Status dropdowns per row
✓ Add new tickets/tasks via the bottom row of each section
✓ Search and filter on Zendesk and Jira tables
✓ Shift handover notes with history
✓ Save to Excel — downloads updated file to upload back to SharePoint

REQUIREMENTS
────────────
• Microsoft 365 account (any plan) with access to SharePoint
• Power Automate (included in M365 — no extra licence)
• Modern browser: Chrome 90+, Edge 90+, Firefox 90+, Safari 16+

SUPPORT
───────
See SETUP_GUIDE.html for troubleshooting.
Common issues: flow URL wrong, table names wrong, CORS header missing.
